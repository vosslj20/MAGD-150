let colors = ["Red", "Orange", "Green", "Blue", "Purple"]
  let myColors = []
  let myColorsY = []
  let myColorsX = []
let shapes = ["Circle", "Triangle", "Square", "Rectangle", "Oval"]
  let myShapes = []
  let myShapesY = []
  let myShapesX = []
function setup() {
  createCanvas(400, 400)
  background(100)
  for (let a = 0; a<4; a++){
    let num = Math.floor(random(0,colors.length))
    console.log(num);
    myColors.push(colors[num])
    colors.splice(num,1);
    myColorsX.push(random(10,width-30))
    myColorsY.push(random(10,height-50))
  }
  for (let c = 0; c<4; c++){
    let ble = Math.floor(random(0,shapes.length))
    console.log(ble);
    myShapes.push(shapes[ble])
    shapes.splice(ble,1);
    myShapesX.push(random(10,width-30))
    myShapesY.push(random(10,height-50))
  }   
text("Array 1: Red, Orange, Green, Blue, Purple", width/3,height-100)
text("Array 2: Circle, Trinagle, Square, Rectangle, Oval", width/3,height-80)
text("Random 1:"+colors[0], width/3,height-60)
text("Random 2:"+shapes[0], width/3, height -40)
text("Random 1 & 2:"+colors[0]+" "+shapes[0], width/3, height-20)
}