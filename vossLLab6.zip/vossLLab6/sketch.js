let ballX = [];
let ballY = [];
let num=15;
let shapeX = [];

function setup() {
  createCanvas(400, 400);
  for (let i = 0; i < num; i++){
    ballX[i] = -100
      ballY[i] = -100
    
  noStroke();
      for (let h = 0; h < 500; h++) {
        shapeX[h] = random(-500, 500);
        console.log(shapeX)

}
}
}
   
function draw() {
  background(0);
  for (let h = 0; h < shapeX.length; h++) {
    shapeX[h] +=1;
      let y = h * 0.75;
        arc(shapeX[h], y, 12, 12, 5.25, 4.25);
    //This is a cat i guess (I tried lol)
    
  fill(255,150,0)
      noStroke()
  for(let n=0; n<ballX.length; n++){
    ballX[ballX.length-1]=mouseX
      ballY[ballY.length-1]=mouseY
  circle(ballX[n], ballY[n],30)
    ballX[n] = ballX[n+1]
        ballY[n] = ballY[n+1]

}
}
}