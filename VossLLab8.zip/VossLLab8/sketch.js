let img1
let img2

function preload(){
  img1 = loadImage('/assets/turkey.png')
  //turkey.png from https://blog.meyerhatchery.com/all-about-turkeys/
  img2 = loadImage('/assets/thanks.png')
  // thanks.png from https://news.njit.edu/file/happy-thanksgiving-typography-badge-vector-calligraphy42237-255png-0
}

function setup() {
  createCanvas(1000, 1000);
}

function draw() {
  background(100);
  fill(204, 85, 0)
  textFont('Arial')
  textSize(72)
  text("It's giving thanks 💅", 225, 900)
  image(img2, 0, 0)
  scale(0.5)
  image(img1, mouseX, mouseY)
}